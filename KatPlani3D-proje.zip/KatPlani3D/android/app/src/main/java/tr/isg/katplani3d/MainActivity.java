package tr.isg.katplani3d;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 11;
    private WebView web;
    private ValueCallback<Uri[]> fileCb;
    private Uri cameraUri;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.addJavascriptInterface(new Bridge(this), "AndroidHost");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                Uri u = req.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                cameraUri = null;
                String[] acc = p.getAcceptTypes();
                String type = (acc != null && acc.length > 0 && acc[0] != null && !acc[0].isEmpty()) ? acc[0] : "*/*";
                if (type.startsWith(".")) type = "*/*";
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType(type);
                if (p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                Intent chooser = Intent.createChooser(pick, "Fotoğraf seç veya çek");
                // Görüntü isteniyorsa kamera seçeneği de sunulur (Android 10 ve üstü)
                if (type.startsWith("image") && Build.VERSION.SDK_INT >= 29) {
                    try {
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.Images.Media.DISPLAY_NAME, "kat3d_" + System.currentTimeMillis() + ".jpg");
                        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                        cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/KatPlani3D");
                        cameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                        if (cameraUri != null) {
                            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
                        }
                    } catch (Exception ignored) { cameraUri = null; }
                }
                try {
                    startActivityForResult(chooser, REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });

        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_FILE || fileCb == null) return;
        List<Uri> out = new ArrayList<>();
        if (res == RESULT_OK) {
            if (data != null && data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) out.add(data.getClipData().getItemAt(i).getUri());
            } else if (data != null && data.getData() != null) {
                out.add(data.getData());
            } else if (cameraUri != null) {
                out.add(cameraUri); // kamerayla çekilen fotoğraf
            }
        }
        if (out.isEmpty() && cameraUri != null) {
            try { getContentResolver().delete(cameraUri, null, null); } catch (Exception ignored) { }
        }
        fileCb.onReceiveValue(out.isEmpty() ? null : out.toArray(new Uri[0]));
        fileCb = null;
        cameraUri = null;
    }

    private void callback(String id, boolean ok, String text) {
        final String js = "window.__hostCb(" + JSONObject.quote(id) + "," + ok + "," + JSONObject.quote(text == null ? "" : text) + ")";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    /** Sayfanın kullandığı köprü: kayıt, ayarlar, Claude API, dışa aktarma. */
    class Bridge {
        private final Context ctx;
        private final SharedPreferences prefs;
        private final File projDir;

        Bridge(Context c) {
            ctx = c;
            prefs = c.getSharedPreferences("ayarlar", MODE_PRIVATE);
            projDir = new File(c.getFilesDir(), "katlar");
            projDir.mkdirs();
        }

        @JavascriptInterface
        public String listProjects() {
            StringBuilder sb = new StringBuilder("[");
            File[] files = projDir.listFiles((d, n) -> n.endsWith(".json"));
            boolean first = true;
            if (files != null) for (File f : files) {
                try {
                    String s = new String(readAll(new FileInputStream(f)), StandardCharsets.UTF_8).trim();
                    if (!s.startsWith("{")) continue;
                    if (!first) sb.append(',');
                    sb.append(s);
                    first = false;
                } catch (Exception ignored) { }
            }
            return sb.append(']').toString();
        }

        @JavascriptInterface
        public String saveProject(String id, String json) {
            if (id == null || !id.matches("[A-Za-z0-9_-]{1,80}")) return "geçersiz kimlik";
            try {
                File tmp = new File(projDir, id + ".tmp");
                try (OutputStream o = new FileOutputStream(tmp)) { o.write(json.getBytes(StandardCharsets.UTF_8)); }
                File dst = new File(projDir, id + ".json");
                if (!tmp.renameTo(dst)) {
                    try (OutputStream o = new FileOutputStream(dst)) { o.write(json.getBytes(StandardCharsets.UTF_8)); }
                    tmp.delete();
                }
                return "ok";
            } catch (Exception e) {
                return String.valueOf(e.getMessage());
            }
        }

        @JavascriptInterface
        public String getSetting(String k) {
            String v = prefs.getString(k, "");
            if ("apiKey".equals(k)) return v.isEmpty() ? "" : "set"; // anahtar sayfaya geri verilmez
            return v;
        }

        @JavascriptInterface
        public void setSetting(String k, String v) {
            prefs.edit().putString(k, v == null ? "" : v.trim()).apply();
        }

        @JavascriptInterface
        public void claude(final String id, final String body) {
            new Thread(() -> {
                HttpURLConnection c = null;
                try {
                    String key = prefs.getString("apiKey", "");
                    if (key.isEmpty()) { callback(id, true, "{\"type\":\"error\",\"error\":{\"message\":\"API anahtarı girilmemiş\"}}"); return; }
                    c = (HttpURLConnection) new URL("https://api.anthropic.com/v1/messages").openConnection();
                    c.setRequestMethod("POST");
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(360000);
                    c.setDoOutput(true);
                    c.setRequestProperty("x-api-key", key);
                    c.setRequestProperty("anthropic-version", "2023-06-01");
                    c.setRequestProperty("content-type", "application/json");
                    try (OutputStream o = c.getOutputStream()) { o.write(body.getBytes(StandardCharsets.UTF_8)); }
                    int code = c.getResponseCode();
                    InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                    String resp = in == null ? "" : new String(readAll(in), StandardCharsets.UTF_8);
                    if (resp.isEmpty()) resp = "{\"type\":\"error\",\"error\":{\"message\":\"Boş yanıt (HTTP " + code + ")\"}}";
                    callback(id, true, resp);
                } catch (Exception e) {
                    callback(id, false, String.valueOf(e.getMessage()));
                } finally {
                    if (c != null) c.disconnect();
                }
            }).start();
        }

        @JavascriptInterface
        public String saveFile(String name, String text) {
            String n = (name == null ? "kat.json" : name).replaceAll("[\\\\/:*?\"<>|]", "_");
            byte[] b = text.getBytes(StandardCharsets.UTF_8);
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, n);
                    cv.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                    cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/KatPlani3D");
                    Uri u = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (u == null) throw new Exception("dosya oluşturulamadı");
                    try (OutputStream o = ctx.getContentResolver().openOutputStream(u)) { o.write(b); }
                    return "İndirilenler/KatPlani3D/" + n;
                } else {
                    File d = ctx.getExternalFilesDir("disa_aktarilan");
                    File f = new File(d, n);
                    try (OutputStream o = new FileOutputStream(f)) { o.write(b); }
                    return f.getAbsolutePath();
                }
            } catch (Exception e) {
                return "hata: " + e.getMessage();
            }
        }
    }

    static byte[] readAll(InputStream in) throws java.io.IOException {
        try (InputStream i = in) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = i.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        }
    }
}
