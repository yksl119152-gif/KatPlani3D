# Kat Planı 3D Tahliye

Kat planından 3D tahliye modeli, oda fotoğraflarından eşya yerleştirme ve kaçış yolu kontrolleri.

- `web/index.html` — programın kendisi (APK ve JAR aynı sayfayı kullanır)
- `android/` — Android uygulaması (WebView)
- `jar/` — masaüstü sürümü (Edge/Chrome uygulama penceresinde açılır)
- `.github/workflows/derle.yml` — GitHub'a her yüklemede APK ve JAR'ı derler

Derlenen dosyalar: Actions → son çalışma → Artifacts bölümü (KatPlani3D-APK, KatPlani3D-JAR).

Masaüstü verileri: Belgeler\KatPlani3D (katlar, dışa aktarılanlar, ayarlar).
Plan ve fotoğraf okuma için Anthropic API anahtarı gerekir; programda Plan sekmesi → "Claude API ayarı".
