import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.awt.Desktop;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.BindException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ProxySelector;
import java.net.URI;
import java.net.URLDecoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.Executors;

/**
 * Kat Planı 3D Tahliye — masaüstü sürümü.
 * Programı yerel bir sunucu olarak çalıştırır ve kendi penceresinde (Edge/Chrome uygulama penceresi) açar.
 * Veriler: Belgeler\KatPlani3D klasörü.
 */
public class KatPlani3D {
    static final int PORT = 17853;
    static final String URL = "http://127.0.0.1:" + PORT + "/";
    static Path dir, projDir, exportDir, libDir, settingsFile;
    static volatile long lastPing = 0;
    static final HttpClient http = HttpClient.newBuilder()
            .proxy(ProxySelector.getDefault())
            .connectTimeout(Duration.ofSeconds(20)).build();

    public static void main(String[] args) throws Exception {
        HttpServer server;
        try {
            server = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), PORT), 0);
        } catch (BindException e) {
            openWindow(); // program zaten açık: yalnızca pencereyi aç
            return;
        }
        Path home = Paths.get(System.getProperty("user.home"));
        Path docs = home.resolve("Documents");
        if (!Files.isDirectory(docs)) docs = home;
        dir = docs.resolve("KatPlani3D");
        projDir = dir.resolve("katlar");
        exportDir = dir.resolve("disa_aktarilan");
        libDir = dir.resolve("lib");
        settingsFile = dir.resolve("ayarlar.properties");
        for (Path p : new Path[]{projDir, exportDir, libDir}) Files.createDirectories(p);

        server.createContext("/", KatPlani3D::handle);
        server.setExecutor(Executors.newCachedThreadPool());
        server.start();
        openWindow();

        Thread watch = new Thread(() -> {
            long started = System.currentTimeMillis();
            while (true) {
                try { Thread.sleep(10000); } catch (InterruptedException ignored) { }
                long now = System.currentTimeMillis();
                // Pencere kapandıktan ~3 dakika sonra kendini kapatır
                if (lastPing > 0 && now - lastPing > 180000) System.exit(0);
                // Pencere hiç açılmadıysa 30 dakika sonra kapanır
                if (lastPing == 0 && now - started > 1800000) System.exit(0);
            }
        });
        watch.setDaemon(false);
        watch.start();
    }

    // ---------- Pencere ----------
    static void openWindow() {
        String os = System.getProperty("os.name", "").toLowerCase();
        List<String> cands = new ArrayList<>();
        if (os.contains("win")) {
            for (String env : new String[]{"ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"}) {
                String b = System.getenv(env);
                if (b == null) continue;
                cands.add(b + "\\Microsoft\\Edge\\Application\\msedge.exe");
                cands.add(b + "\\Google\\Chrome\\Application\\chrome.exe");
            }
        } else if (os.contains("mac")) {
            cands.add("/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge");
            cands.add("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome");
        } else {
            cands.add("/usr/bin/microsoft-edge");
            cands.add("/usr/bin/google-chrome");
            cands.add("/usr/bin/chromium");
            cands.add("/usr/bin/chromium-browser");
        }
        for (String c : cands) {
            if (new File(c).isFile()) {
                try {
                    new ProcessBuilder(c, "--app=" + URL, "--window-size=1400,900").start();
                    return;
                } catch (IOException ignored) { }
            }
        }
        try {
            if (Desktop.isDesktopSupported()) Desktop.getDesktop().browse(new URI(URL));
        } catch (Exception ignored) { }
    }

    // ---------- İstekler ----------
    static void handle(HttpExchange ex) throws IOException {
        try {
            String path = ex.getRequestURI().getPath();
            String m = ex.getRequestMethod();
            if (!m.equals("GET") && !"1".equals(ex.getRequestHeaders().getFirst("X-Kat"))) {
                send(ex, 403, "text/plain", "izin yok");
                return;
            }
            if (path.equals("/") || path.equals("/index.html")) {
                byte[] b = resource("/web/index.html");
                if (b == null) { send(ex, 500, "text/plain", "index.html bulunamadı"); return; }
                send(ex, 200, "text/html; charset=utf-8", b);
            } else if (path.startsWith("/lib/")) {
                String name = path.substring(5);
                if (!name.matches("[A-Za-z0-9._-]+\\.js")) { send(ex, 404, "text/plain", "yok"); return; }
                byte[] b = lib(name);
                if (b == null) send(ex, 404, "text/plain", "kütüphane indirilemedi");
                else send(ex, 200, "application/javascript; charset=utf-8", b);
            } else if (path.equals("/api/ping")) {
                lastPing = System.currentTimeMillis();
                send(ex, 200, "text/plain", "ok");
            } else if (path.equals("/api/projects") && m.equals("GET")) {
                StringBuilder sb = new StringBuilder("[");
                boolean first = true;
                try (DirectoryStream<Path> ds = Files.newDirectoryStream(projDir, "*.json")) {
                    for (Path p : ds) {
                        String s = new String(Files.readAllBytes(p), StandardCharsets.UTF_8).trim();
                        if (!s.startsWith("{")) continue;
                        if (!first) sb.append(',');
                        sb.append(s);
                        first = false;
                    }
                }
                sb.append(']');
                send(ex, 200, "application/json; charset=utf-8", sb.toString());
            } else if (path.startsWith("/api/projects/") && m.equals("PUT")) {
                String id = URLDecoder.decode(path.substring(14), "UTF-8");
                if (!id.matches("[A-Za-z0-9_-]{1,80}")) { send(ex, 400, "text/plain", "geçersiz kimlik"); return; }
                byte[] body = readAll(ex.getRequestBody());
                Path tmp = projDir.resolve(id + ".tmp");
                Files.write(tmp, body);
                Files.move(tmp, projDir.resolve(id + ".json"), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                send(ex, 200, "text/plain", "ok");
            } else if (path.equals("/api/settings")) {
                String k = query(ex, "k");
                if (k == null || !k.matches("[A-Za-z]{1,30}")) { send(ex, 400, "text/plain", ""); return; }
                Properties p = settings();
                if (m.equals("POST")) {
                    p.setProperty(k, new String(readAll(ex.getRequestBody()), StandardCharsets.UTF_8).trim());
                    try (OutputStream o = Files.newOutputStream(settingsFile)) { p.store(o, "Kat Plani 3D ayarlari"); }
                    send(ex, 200, "text/plain", "ok");
                } else {
                    String v = p.getProperty(k, "");
                    if (k.equals("apiKey")) v = v.isEmpty() ? "" : "set"; // anahtar sayfaya geri gönderilmez
                    send(ex, 200, "text/plain; charset=utf-8", v);
                }
            } else if (path.equals("/api/claude") && m.equals("POST")) {
                send(ex, 200, "application/json; charset=utf-8", claude(readAll(ex.getRequestBody())));
            } else if (path.equals("/api/export") && m.equals("POST")) {
                String n = query(ex, "name");
                if (n == null) n = "kat.json";
                n = n.replaceAll("[\\\\/:*?\"<>|]", "_");
                if (!n.toLowerCase().endsWith(".json")) n += ".json";
                Path out = exportDir.resolve(n);
                Files.write(out, readAll(ex.getRequestBody()));
                try { if (Desktop.isDesktopSupported()) Desktop.getDesktop().open(exportDir.toFile()); } catch (Exception ignored) { }
                send(ex, 200, "text/plain; charset=utf-8", out.toString());
            } else {
                send(ex, 404, "text/plain", "yok");
            }
        } catch (Exception e) {
            try { send(ex, 500, "text/plain; charset=utf-8", "Hata: " + e.getMessage()); } catch (Exception ignored) { }
        }
    }

    static String claude(byte[] body) {
        String key = settings().getProperty("apiKey", "");
        if (key.isEmpty()) return err("API anahtarı girilmemiş");
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.anthropic.com/v1/messages"))
                    .timeout(Duration.ofMinutes(6))
                    .header("x-api-key", key)
                    .header("anthropic-version", "2023-06-01")
                    .header("content-type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofByteArray(body)).build();
            HttpResponse<String> r = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            String b = r.body();
            if (b == null || b.isEmpty()) return err("Boş yanıt (HTTP " + r.statusCode() + ")");
            return b;
        } catch (Exception e) {
            return err("Claude'a ulaşılamadı: " + e.getMessage());
        }
    }

    static String err(String msg) {
        return "{\"type\":\"error\",\"error\":{\"message\":\"" + msg.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ") + "\"}}";
    }

    static byte[] lib(String name) {
        byte[] b = resource("/web/lib/" + name);
        if (b != null) return b;
        Path cached = libDir.resolve(name);
        try { if (Files.isRegularFile(cached) && Files.size(cached) > 1000) return Files.readAllBytes(cached); } catch (IOException ignored) { }
        String url = name.equals("three.min.js") ? "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"
                : name.equals("OrbitControls.js") ? "https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js" : null;
        if (url == null) return null;
        try {
            HttpResponse<byte[]> r = http.send(HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(60)).build(), HttpResponse.BodyHandlers.ofByteArray());
            if (r.statusCode() != 200) return null;
            Files.write(cached, r.body());
            return r.body();
        } catch (Exception e) {
            return null;
        }
    }

    static Properties settings() {
        Properties p = new Properties();
        if (Files.isRegularFile(settingsFile)) {
            try (InputStream i = Files.newInputStream(settingsFile)) { p.load(i); } catch (IOException ignored) { }
        }
        return p;
    }

    static String query(HttpExchange ex, String key) throws IOException {
        String q = ex.getRequestURI().getRawQuery();
        if (q == null) return null;
        for (String part : q.split("&")) {
            int i = part.indexOf('=');
            if (i > 0 && part.substring(0, i).equals(key)) return URLDecoder.decode(part.substring(i + 1), "UTF-8");
        }
        return null;
    }

    static byte[] resource(String p) {
        try (InputStream i = KatPlani3D.class.getResourceAsStream(p)) {
            return i == null ? null : readAll(i);
        } catch (IOException e) {
            return null;
        }
    }

    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toByteArray();
    }

    static void send(HttpExchange ex, int code, String type, String body) throws IOException {
        send(ex, code, type, body.getBytes(StandardCharsets.UTF_8));
    }

    static void send(HttpExchange ex, int code, String type, byte[] body) throws IOException {
        ex.getResponseHeaders().set("Content-Type", type);
        ex.getResponseHeaders().set("Cache-Control", "no-store");
        ex.sendResponseHeaders(code, body.length);
        try (OutputStream o = ex.getResponseBody()) { o.write(body); }
    }
}
